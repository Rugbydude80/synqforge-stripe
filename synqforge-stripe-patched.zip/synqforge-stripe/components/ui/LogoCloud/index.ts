export { default } from './LogoCloud';
